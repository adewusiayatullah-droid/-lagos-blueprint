const FEEDS = [
  { url: "https://rss.punchng.com/v1/category/latest_news", publisher: "PUNCH", category: "News", local: false },
  { url: "https://rss.punchng.com/v1/category/entertainment", publisher: "PUNCH", category: "Entertainment", local: false },
  { url: "https://www.vanguardngr.com/feed/", publisher: "Vanguard", category: "Nigeria", local: false },
  { url: "https://thereporter.com.ng/rss/category/lagos-news", publisher: "The Reporter", category: "Lagos News", local: true },
  { url: "https://thereporter.com.ng/rss/category/Entertainment-&-Lifestyle", publisher: "The Reporter", category: "Lifestyle", local: false },
  { url: "https://www.premiumtimesng.com/feed", publisher: "Premium Times", category: "Nigeria", local: false },
  { url: "https://guardian.ng/feed/", publisher: "The Guardian Nigeria", category: "Nigeria", local: false }
];

function clean(value = "") {
  return String(value)
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&").replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/\s+/g, " ").trim();
}
function tag(xml, name) {
  const re = new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${name}>`, "i");
  const m = xml.match(re);
  return m ? clean(m[1]) : "";
}
function parseItems(xml) {
  const rssItems = xml.match(/<item(?:\s[^>]*)?>[\s\S]*?<\/item>/gi) || [];
  if (rssItems.length) return rssItems.map(item => ({
    title: tag(item, "title"),
    url: tag(item, "link"),
    dateRaw: tag(item, "pubDate") || tag(item, "dc:date"),
  }));
  const atomEntries = xml.match(/<entry(?:\s[^>]*)?>[\s\S]*?<\/entry>/gi) || [];
  return atomEntries.map(item => {
    const link = item.match(/<link[^>]+href=["']([^"']+)["']/i);
    return { title: tag(item, "title"), url: link ? link[1] : "", dateRaw: tag(item, "published") || tag(item, "updated") };
  });
}
function categoryFor(item, feed) {
  const hay = `${item.title} ${feed.category}`.toLowerCase();
  if (/food|restaurant|recipe|jollof|chef|dining|eatery|cuisine/.test(hay)) return "Food";
  if (/entertainment|music|film|movie|celebrity|artist|afrobeats|nollywood|concert/.test(hay)) return "Entertainment";
  if (/lifestyle|fashion|culture|travel|tourism|event|arts/.test(hay)) return "Lifestyle";
  if (feed.local || /lagos|lekki|ikeja|surulere|eko/.test(hay)) return "Lagos News";
  return "Nigeria News";
}
function isoDate(raw) {
  const d = new Date(raw);
  return Number.isNaN(d.getTime()) ? "Date unavailable" : d.toISOString();
}

export default async () => {
  const results = await Promise.all(FEEDS.map(async feed => {
    try {
      const response = await fetch(feed.url, {
        headers: { "User-Agent": "LagosBlueprintNewsReader/1.0 (+public RSS headlines)" },
        signal: AbortSignal.timeout(7000)
      });
      if (!response.ok) return [];
      const xml = await response.text();
      return parseItems(xml).map(item => ({
        title: item.title,
        url: item.url,
        publisher: feed.publisher,
        category: categoryFor(item, feed),
        dateISO: isoDate(item.dateRaw),
        date: isoDate(item.dateRaw) === "Date unavailable" ? "Date unavailable" :
          new Date(item.dateRaw).toLocaleString("en-NG", { dateStyle: "medium", timeStyle: "short", timeZone: "Africa/Lagos" })
      })).filter(item =>
        item.title && item.url && /^https?:\/\//i.test(item.url) &&
        item.dateISO !== "Date unavailable" &&
        !/^\s*(advertisement|sponsored content)\s*$/i.test(item.title)
      ).slice(0, 18);
    } catch {
      return [];
    }
  }));
  const unique = new Map();
  for (const item of results.flat()) {
    if (!unique.has(item.url)) unique.set(item.url, item);
  }
  const stories = [...unique.values()]
    .sort((a, b) => new Date(b.dateISO) - new Date(a.dateISO))
    .slice(0, 60);
  return new Response(JSON.stringify({ updatedAt: new Date().toISOString(), stories }), {
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "access-control-allow-origin": "*"
    }
  });
};
