LAGOS BLUEPRINT — AUTOMATIC RSS HEADLINES

What it does
- Loads headlines, publisher names, publication dates, categories and links to original stories.
- The page requests fresh feed data on first load and refreshes every hour while open.
- RSS feed URLs are defined in netlify/functions/news.mjs.
- It only displays headlines and links, not full publisher articles.

Sources currently configured
- PUNCH latest news and entertainment RSS feeds
- Vanguard RSS
- The Reporter Lagos news and Entertainment & Lifestyle RSS feeds
- Premium Times RSS
- The Guardian Nigeria RSS

Important
- RSS availability and publisher terms can change. Check the source's feed terms before public use.
- Category labels are assigned heuristically and may be imperfect.
- This is an automated headline directory, not an independent fact-checking service.
- If no feed returns valid data, the site shows an empty/error status rather than inventing headlines.
- This package includes a Netlify Function. A simple manual drag-and-drop static deploy will NOT deploy the function. You must connect a Git repository to Netlify (or use Netlify CLI from a computer) and deploy the repository.

Android-friendly deploy
1. Download and extract the ZIP on your phone if your file manager supports it.
2. Create a GitHub repository and upload all project files/folders, preserving the paths:
   index.html
   netlify.toml
   netlify/functions/news.mjs
3. In Netlify dashboard, choose Add new project / Import an existing project and connect that GitHub repository.
4. Set build command blank and publish directory "." if asked. The included netlify.toml declares these settings.
5. Deploy. After deploy, open https://YOUR-SITE/.netlify/functions/news to test. It should show JSON with updatedAt and stories. If it returns 404, the Netlify Function was not deployed.
6. Open the homepage. It will request new feed data on load and every hour while the page stays open. Visitors who reopen the page receive fresh feed data.

No API key is required by this version. Netlify Functions are required to fetch feeds server-side because browsers often block cross-site RSS requests.
